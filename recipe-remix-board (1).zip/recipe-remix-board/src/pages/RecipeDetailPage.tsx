import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useRecipes } from "@/hooks/useRecipes";
import { useSubstitutedIngredients } from "@/hooks/useSubstitutedIngredients";
import { DietToggles } from "@/components/DietToggles";
import { IngredientRow } from "@/components/IngredientRow";
import { DEFAULT_RESTRICTIONS, Recipe, Restrictions } from "@/types";
import { ArrowLeft } from "lucide-react";

export function RecipeDetailPage({ recipeId }: { recipeId: string }) {
  const { getRecipe } = useRecipes();
  const navigate = useNavigate();
  const recipe = getRecipe(recipeId);

  // This is the ONLY state for restrictions. Every checkbox reads and
  // writes this same object, so ticking a box updates it instantly and
  // the ingredient list (driven by useSubstitutedIngredients below)
  // re-renders on the same tick - no submit button involved.
  const [restrictions, setRestrictions] = useState<Restrictions>(DEFAULT_RESTRICTIONS);

  // Requirement: switching recipes should reset restrictions instead of
  // carrying them over. We watch recipeId specifically (not the whole
  // recipe object) and reset back to defaults whenever it changes.
  useEffect(() => {
    setRestrictions(DEFAULT_RESTRICTIONS);
  }, [recipeId]);

  // Guard for a bad/deleted id - always call hooks above this line
  // unconditionally, then branch on the data itself.
  if (!recipe) {
    return (
      <div className="max-w-3xl mx-auto p-6">
        <p className="text-gray-500">Recipe not found.</p>
        <Link to="/" className="text-primary underline text-sm">
          Back to all recipes
        </Link>
      </div>
    );
  }

  return (
    <RecipeDetailContent
      restrictions={restrictions}
      setRestrictions={setRestrictions}
      recipe={recipe}
      onBack={() => navigate({ to: "/" })}
    />
  );
}

// Split out so useSubstitutedIngredients only ever runs with a
// guaranteed non-null recipe (keeps the hook call unconditional above).
function RecipeDetailContent({
  recipe,
  restrictions,
  setRestrictions,
  onBack,
}: {
  recipe: Recipe;
  restrictions: Restrictions;
  setRestrictions: (r: Restrictions) => void;
  onBack: () => void;
}) {
  const resolvedIngredients = useSubstitutedIngredients(recipe, restrictions);
  const changedCount = resolvedIngredients.filter((i) => i.changed).length;

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-sm text-foreground/50 hover:text-foreground transition-colors mb-4"
      >
        <ArrowLeft className="h-4 w-4" /> All recipes
      </button>

      {/* Side-by-side on desktop (md:flex-row), stacked on mobile (flex-col) */}
      <div className="flex flex-col md:flex-row gap-8">
        <div className="md:w-1/2">
          <img
            src={recipe.imageUrl}
            alt={recipe.name}
            className="w-full h-56 sm:h-72 object-cover rounded-lg shadow-[0_1px_2px_rgba(60,50,30,0.08)]"
          />
          <h1 className="text-2xl font-display font-semibold mt-4">{recipe.name}</h1>
          <p className="text-foreground/55 text-sm mt-1">{recipe.description}</p>

          <div className="mt-6 bg-white rounded-lg border border-border p-4">
            <h2 className="text-sm font-semibold mb-3">Dietary restrictions</h2>
            <DietToggles restrictions={restrictions} onChange={setRestrictions} />
          </div>
        </div>

        <div className="md:w-1/2">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm font-semibold">Ingredients</h2>
            {changedCount > 0 && (
              <span className="text-xs text-accent font-medium">
                {changedCount} substitution{changedCount > 1 ? "s" : ""} applied
              </span>
            )}
          </div>
          <ul className="flex flex-col gap-1 bg-white border border-border rounded-lg p-2">
            {resolvedIngredients.map((ingredient) => (
              <IngredientRow key={ingredient.id} ingredient={ingredient} />
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
