import { Link } from "@tanstack/react-router";
import { useRecipes } from "@/hooks/useRecipes";
import { RecipeCard } from "@/components/RecipeCard";
import { Button } from "@/components/ui/button";
import { Plus, UtensilsCrossed } from "lucide-react";

export function RecipeListPage() {
  const { recipes, deleteRecipe } = useRecipes();

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6">
      <div className="flex items-start sm:items-center justify-between gap-4 mb-8 flex-col sm:flex-row">
        <div>
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-accent bg-accent/10 rounded-full px-2.5 py-1 mb-2">
            <UtensilsCrossed className="h-3 w-3" /> one meal, every diet
          </span>
          <h1 className="text-3xl font-display font-semibold tracking-tight">
            Recipe Remix Board
          </h1>
          <p className="text-foreground/55 text-sm mt-1">
            Pick a recipe, tick off restrictions, watch the ingredients rewrite themselves.
          </p>
        </div>
        <Link to="/recipe/new">
          <Button>
            <Plus className="h-4 w-4" /> New recipe
          </Button>
        </Link>
      </div>

      {recipes.length === 0 ? (
        <p className="text-foreground/50 text-sm">
          No recipes yet - add one to get started.
        </p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {recipes.map((recipe) => (
            <RecipeCard key={recipe.id} recipe={recipe} onDelete={deleteRecipe} />
          ))}
        </div>
      )}
    </div>
  );
}
