import { useNavigate } from "@tanstack/react-router";
import { useRecipes } from "@/hooks/useRecipes";
import { RecipeForm } from "@/components/RecipeForm";
import { Recipe } from "@/types";

export function RecipeFormPage({ recipeId }: { recipeId?: string }) {
  const { getRecipe, addRecipe, updateRecipe } = useRecipes();
  const navigate = useNavigate();
  const existing = recipeId ? getRecipe(recipeId) : undefined;

  function handleSave(recipe: Recipe) {
    if (existing) {
      updateRecipe(existing.id, recipe);
    } else {
      addRecipe(recipe);
    }
    navigate({ to: "/" });
  }

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6">
      <h1 className="text-xl font-bold mb-4">
        {existing ? `Edit "${existing.name}"` : "Add a new recipe"}
      </h1>
      <RecipeForm
        initial={existing}
        onSave={handleSave}
        onCancel={() => navigate({ to: "/" })}
      />
    </div>
  );
}
