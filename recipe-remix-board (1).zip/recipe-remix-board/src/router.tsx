import {
  createRootRoute,
  createRoute,
  createRouter,
  Outlet,
} from "@tanstack/react-router";
import { RecipeListPage } from "@/pages/RecipeListPage";
import { RecipeDetailPage } from "@/pages/RecipeDetailPage";
import { RecipeFormPage } from "@/pages/RecipeFormPage";

// The root route just renders whatever child route matched, via <Outlet />.
// Think of it as the shared "page frame" every route lives inside.
const rootRoute = createRootRoute({
  component: () => <Outlet />,
});

// "/" -> browse & pick a recipe
const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: RecipeListPage,
});

// "/recipe/new" -> create form.
// NOTE: this must be registered before the "/recipe/$recipeId" route
// below so that the literal "new" segment isn't swallowed by the
// dynamic $recipeId param matcher.
const newRecipeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/recipe/new",
  component: () => <RecipeFormPage />,
});

// "/recipe/:recipeId" -> detail page with diet toggles + ingredient list
const recipeDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/recipe/$recipeId",
  component: () => {
    const { recipeId } = recipeDetailRoute.useParams();
    return <RecipeDetailPage recipeId={recipeId} />;
  },
});

// "/recipe/:recipeId/edit" -> edit form, pre-filled with the recipe
const editRecipeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/recipe/$recipeId/edit",
  component: () => {
    const { recipeId } = editRecipeRoute.useParams();
    return <RecipeFormPage recipeId={recipeId} />;
  },
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  newRecipeRoute,
  recipeDetailRoute,
  editRecipeRoute,
]);

export const router = createRouter({ routeTree });

// Lets TypeScript know about our specific router shape, so things like
// <Link to="/recipe/$recipeId" params={{ recipeId }} /> are type-checked.
declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}
