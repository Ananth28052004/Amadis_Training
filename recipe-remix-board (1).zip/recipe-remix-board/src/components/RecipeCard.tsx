import { Link } from "@tanstack/react-router";
import { Recipe } from "@/types";
import { Card, CardContent, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";

interface Props {
  recipe: Recipe;
  onDelete: (id: string) => void;
}

export function RecipeCard({ recipe, onDelete }: Props) {
  return (
    <Card className="overflow-hidden flex flex-col transition-all duration-200 hover:shadow-[0_6px_20px_rgba(60,50,30,0.10)] hover:-translate-y-0.5">
      {/* Whole image + title area links to the detail page */}
      <Link to="/recipe/$recipeId" params={{ recipeId: recipe.id }}>
        <img
          src={recipe.imageUrl}
          alt={recipe.name}
          className="h-40 w-full object-cover"
        />
      </Link>
      <CardContent className="flex flex-col flex-1 gap-2">
        <Link to="/recipe/$recipeId" params={{ recipeId: recipe.id }}>
          <CardTitle className="hover:text-primary transition-colors">
            {recipe.name}
          </CardTitle>
        </Link>
        <p className="text-sm text-foreground/55 flex-1">
          {recipe.description}
        </p>
        <div className="flex justify-between items-center pt-2 border-t border-border/70">
          <span className="text-xs text-foreground/40">
            {recipe.ingredients.length} ingredients
          </span>
          <div className="flex gap-1">
            <Link to="/recipe/$recipeId/edit" params={{ recipeId: recipe.id }}>
              <Button variant="ghost" size="icon" title="Edit recipe">
                <Pencil className="h-4 w-4" />
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              title="Delete recipe"
              onClick={() => {
                if (confirm(`Delete "${recipe.name}"?`)) onDelete(recipe.id);
              }}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
