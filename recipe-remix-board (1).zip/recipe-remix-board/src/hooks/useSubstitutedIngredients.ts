import { useMemo } from "react";
import { DIET_ORDER, Recipe, Restrictions, ResolvedIngredient } from "@/types";

/**
 * Turns a recipe's raw ingredient list into the list we actually show
 * on screen, applying substitutions for whichever restrictions are on.
 *
 * Why useMemo:
 * React re-renders this component on every checkbox click, but we only
 * want to redo this loop when the recipe changes OR the restrictions
 * change - not on every unrelated re-render. useMemo caches the result
 * and only recalculates when something in the dependency array changes.
 */
export function useSubstitutedIngredients(
  recipe: Recipe,
  restrictions: Restrictions
): ResolvedIngredient[] {
  return useMemo(() => {
    // Which diets are currently switched on, in priority order.
    const activeDiets = DIET_ORDER.filter((diet) => restrictions[diet]);

    return recipe.ingredients.map((ingredient): ResolvedIngredient => {
      // Find the first active diet that has a substitution rule for
      // this ingredient. Priority order (vegan > glutenFree > dairyFree)
      // decides the winner if more than one applies.
      const matchedDiet = activeDiets.find((diet) => ingredient.subs?.[diet]);

      if (!matchedDiet) {
        // No substitution needed - show the ingredient as-is.
        return {
          id: ingredient.id,
          quantity: ingredient.quantity,
          displayName: ingredient.name,
          originalName: ingredient.name,
          changed: false,
          significant: false,
        };
      }

      const sub = ingredient.subs![matchedDiet]!;
      return {
        id: ingredient.id,
        quantity: ingredient.quantity,
        displayName: sub.name,
        originalName: ingredient.name,
        changed: true,
        significant: sub.significant,
        note: sub.note,
        appliedFor: matchedDiet,
      };
    });
    // Dependency array: only recompute when the recipe identity changes,
    // or when one of the 3 restriction flags flips. Listing the individual
    // boolean flags (rather than the whole `restrictions` object) means
    // we don't need to worry about object-reference equality either.
  }, [recipe.id, restrictions.vegan, restrictions.glutenFree, restrictions.dairyFree]);
}
