import { useState, useEffect } from "react";

// A useState() that also reads/writes localStorage, so data survives
// page refreshes. This is our whole "database" for this app.
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = window.localStorage.getItem(key);
      return stored ? (JSON.parse(stored) as T) : initialValue;
    } catch {
      // If localStorage is corrupted or unavailable, fall back gracefully.
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Ignore write errors (e.g. private browsing storage limits).
    }
  }, [key, value]);

  return [value, setValue] as const;
}
